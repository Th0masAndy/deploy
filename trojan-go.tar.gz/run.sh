nohup ./trojan-go -config client.json >> log 2>&1 &
ps -aux | grep trojan-go